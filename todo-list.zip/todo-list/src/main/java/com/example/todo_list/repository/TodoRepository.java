package com.example.todo_list.repository;

import com.example.todo_list.dao.TodoDAO;
import com.example.todo_list.model.Todo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TodoRepository {

    private final TodoDAO todoDAO;

    @Autowired
    public TodoRepository(TodoDAO todoDAO) {
        this.todoDAO = todoDAO;
    }

    public List<Todo> findAll() {
        return todoDAO.findAll();
    }

    public void save(Todo todo) {
        todoDAO.save(todo);
    }

    public void deleteById(int id) {
        todoDAO.deleteById(id);
    }

    public void update(Todo todo) {
        todoDAO.update(todo);
    }
}

package com.example.todo_list.dao;

import com.example.todo_list.model.Todo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TodoDAO {

    private final Connection connection;

    public TodoDAO(Connection connection) {
        this.connection = connection;
    }

    // Tüm Todo'ları al
    public List<Todo> findAll() {
        List<Todo> todos = new ArrayList<>();
        String query = "SELECT * FROM todos";

        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Todo todo = new Todo();
                todo.setId(rs.getInt("id"));
                todo.setTitle(rs.getString("title"));
                todo.setDescription(rs.getString("description"));
                todo.setDone(rs.getBoolean("is_done"));
                todo.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
                todos.add(todo);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Hata kontrolü
        }
        return todos;
    }

    // Todo ekle
    public void save(Todo todo) {
        String query = "INSERT INTO todos (title, description, is_done, created_at) VALUES (?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, todo.getTitle());
            pstmt.setString(2, todo.getDescription());
            pstmt.setBoolean(3, todo.isDone());
            pstmt.setTimestamp(4, Timestamp.valueOf(todo.getCreatedAt()));
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Hata kontrolü
        }
    }

    // Todo sil
    public void deleteById(int id) {
        String query = "DELETE FROM todos WHERE id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Hata kontrolü
        }
    }

    // Todo güncelle
    public void update(Todo todo) {
        String query = "UPDATE todos SET title = ?, description = ?, is_done = ?, created_at = ? WHERE id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, todo.getTitle());
            pstmt.setString(2, todo.getDescription());
            pstmt.setBoolean(3, todo.isDone());
            pstmt.setTimestamp(4, Timestamp.valueOf(todo.getCreatedAt()));
            pstmt.setInt(5, todo.getId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace(); // Hata kontrolü
        }
    }
}

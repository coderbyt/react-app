package com.example.todo_list.service;

import com.example.todo_list.dao.TodoDAO;
import com.example.todo_list.model.Todo;

import java.sql.Connection;
import java.util.List;

public class TodoService {

    private final TodoDAO todoDAO;

    public TodoService(Connection connection) {
        this.todoDAO = new TodoDAO(connection);
    }

    // Tüm Todo'ları al
    public List<Todo> getAllTodos() {
        return todoDAO.findAll();
    }

    // Todo ekle
    public void addTodo(Todo todo) {
        todoDAO.save(todo);
    }

    // Todo sil
    public void deleteTodoById(int id) {
        todoDAO.deleteById(id);
    }

    // Todo güncelle
    public void updateTodo(Todo todo) {
        if (todo.getId() == 0) {
            throw new IllegalArgumentException("Todo ID must be provided.");
        }
        todoDAO.update(todo);
    }
}

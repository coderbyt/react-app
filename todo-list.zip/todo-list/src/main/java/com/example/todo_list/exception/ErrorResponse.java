package com.example.todo_list.exception;

public class ErrorResponse {
    private String message;
    private String details;
    private int errorCode;

    public ErrorResponse(String message, String details, int errorCode) {
        this.message = message;
        this.details = details;
        this.errorCode = errorCode;
    }

    // Getter ve Setter'lar
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }
}

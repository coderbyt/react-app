package com.example.todo_list.controller;

import com.example.todo_list.model.Todo;
import com.example.todo_list.service.TodoService;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

import java.sql.Connection;
import java.util.List;

@RestController
@RequestMapping("/api/todos")
public class TodoController {

    private final TodoService todoService;

    // Constructor üzerinden bağlantıyı alıyoruz
    public TodoController(Connection connection) {
        this.todoService = new TodoService(connection);
    }

    // Tüm Todo'ları al
    @GetMapping
    public List<Todo> getTodos() {
        return todoService.getAllTodos();
    }

    // Todo ekle
    @PostMapping
    public void addTodo(@RequestBody Todo todo) {
        todoService.addTodo(todo);
    }

    // Todo sil
    @DeleteMapping("/{id}")
    public void deleteTodoById(@PathVariable int id) {
        todoService.deleteTodoById(id);
    }

    // Todo güncelle
    @PutMapping("/{id}")
    public ResponseEntity<Void> updateTodo(@PathVariable int id, @RequestBody Todo todo) {
        if (id != todo.getId()) {
            return ResponseEntity.badRequest().build();
        }

        todoService.updateTodo(todo);
        return ResponseEntity.ok().build();
    }
}

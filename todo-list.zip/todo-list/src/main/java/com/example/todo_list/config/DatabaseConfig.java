package com.example.todo_list.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DatabaseConfig {

    @Bean
    public Connection connection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/todolist_db?useSSL=false&serverTimezone=UTC";
        String username = "root";
        String password = "your_password"; // Şifrenizi burada belirtin
        return DriverManager.getConnection(url, username, password);
    }
}

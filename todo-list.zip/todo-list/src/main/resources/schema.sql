CREATE TABLE IF NOT EXISTS TODOS (
                                     id INT AUTO_INCREMENT PRIMARY KEY,
                                     title VARCHAR(255) NOT NULL,
    description VARCHAR(500),
    is_done BOOLEAN DEFAULT FALSE,
    created_At DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

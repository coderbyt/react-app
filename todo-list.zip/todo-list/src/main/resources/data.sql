/*INSERT INTO TODOS (title, description, is_done) VALUES ('ilk görev', 'basit bir görev.', false);
INSERT INTO TODOS (title, description, is_done) VALUES ('ikinci görev', 'başka bir görev açıklaması.', true);
*/